package org.Saveable;

public interface Saveable {
}
